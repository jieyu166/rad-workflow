#!/usr/bin/env python3
"""
generate_report.py — 讀取 tracker.xlsx + week_input.md → 產出 HTML 週報

Usage:
    python scripts/generate_report.py data/tracker.xlsx data/week_input.md -o output/weekly_report.html

若 week_input.md 未提供期初/期末，會提示使用者補充。
"""

import argparse
import json
import re
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

try:
    import openpyxl
except ImportError:
    print("需要安裝 openpyxl: pip install openpyxl")
    sys.exit(1)


# ── Baselines (from claude.md) ──────────────────────────────────────────────
BASELINES = {
    'X光(普通)': 50, 'X光(急打)': 35, 'X光(中等)': 30, 'X光(困難)': 20,
    'CT(Chest/Abd)': 3.5, 'CT(Brain)': 7, 'CT(Neck/CTA)': 3.5, 'CT(Brain-C)': 3,
    'US(一般)': 18, 'US(困難)': 4,
    'Mammo': 22, 'MR': 2, 'IVP': 12, 'BMD': 60,
}

MOD_MAP = {'xr': 'X光', 'ct': 'CT', 'us': 'US', 'mm': 'Mammo', 'mr': 'MR',
           'bmd': 'BMD', 'other': '其他', 'ivp': 'IVP'}
TRACKED_MODS = ['X光', 'CT', 'US', 'Mammo']
ALL_MODS = ['X光', 'CT', 'US', 'Mammo', 'MR', 'BMD', 'IVP']
DAY_ORDER = ['一', '二', '三', '四', '五', '六', '日']


def parse_xlsx(path: str) -> list[dict]:
    """Parse tracker.xlsx and return list of entry dicts."""
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb['每日工作紀錄']
    entries = []
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row, values_only=True):
        date, weekday, ts, mod, sub, diff, count, mins, rate, note = row
        if date is None or (isinstance(date, str) and '2025' in date):
            continue
        mod_str = str(mod).lower().strip() if mod else ''
        mod_norm = MOD_MAP.get(mod_str, mod_str)
        sub_cat = sub or diff or ''
        entries.append({
            'date': date, 'weekday': str(weekday).strip(),
            'time': ts, 'mod': mod_norm, 'sub': str(sub_cat).strip(),
            'count': float(count) if count else 0,
            'mins': float(mins) if mins else 0,
            'rate': float(rate) if rate else 0,
            'note': str(note).strip() if note and str(note) != 'None' else ''
        })
    return entries


def parse_week_input(path: str) -> dict:
    """Parse week_input.md for start/end remaining and metadata."""
    text = Path(path).read_text(encoding='utf-8')
    info = {'start': {}, 'end': {}, 'mid': {}, 'study_hr': 0, 'notes': []}

    # Simple regex extraction
    for line in text.split('\n'):
        line = line.strip()
        if '期初剩餘' in line:
            nums = re.findall(r'[XxＸ光xr]*\s*(\d+)份', line)
            # More robust: look for pattern "X光 NNN份"
            for mod in ['X光', 'CT', 'US', 'Mammo']:
                m = re.search(rf'{mod}\s*(\d+)', line, re.IGNORECASE)
                if m:
                    info['start'][mod] = int(m.group(1))
        if '期末剩餘' in line:
            for mod in ['X光', 'CT', 'US', 'Mammo']:
                m = re.search(rf'{mod}\s*(\d+)', line, re.IGNORECASE)
                if m:
                    info['end'][mod] = int(m.group(1))

    return info


def group_by_day(entries: list[dict]) -> dict:
    """Group entries by work day (using weekday field)."""
    daily = {}
    for wd in DAY_ORDER:
        daily[wd] = {
            'entries': [], 'report_min': 0, 'clinical_min': 0, 'misc_min': 0,
            'notes': set(),
            **{m: 0 for m in ALL_MODS},
            'xr_sub': defaultdict(lambda: {'c': 0, 'm': 0}),
            'ct_sub': defaultdict(lambda: {'c': 0, 'm': 0}),
            'us_sub': defaultdict(lambda: {'c': 0, 'm': 0}),
        }

    for e in entries:
        wd = e['weekday']
        if wd not in daily:
            continue
        d = daily[wd]
        d['entries'].append(e)
        mod, count, mins = e['mod'], e['count'], e['mins']

        if mod == '其他':
            if '臨床' in e['sub']:
                d['clinical_min'] += mins
            else:
                d['misc_min'] += mins
            continue

        d['report_min'] += mins
        if mod in d:
            d[mod] += count

        if mod == 'X光':
            sub = e['sub'] if e['sub'] else '普通'
            d['xr_sub'][sub]['c'] += count
            d['xr_sub'][sub]['m'] += mins
        elif mod == 'CT':
            sub = e['sub'] if e['sub'] else 'Chest/Abd'
            d['ct_sub'][sub]['c'] += count
            d['ct_sub'][sub]['m'] += mins
        elif mod == 'US':
            sub = e['sub'] if e['sub'] else '一般'
            d['us_sub'][sub]['c'] += count
            d['us_sub'][sub]['m'] += mins

        if e['note']:
            d['notes'].add(e['note'])

    return daily


def compute_totals(daily: dict) -> dict:
    """Compute weekly totals from daily data."""
    totals = {m: 0 for m in ALL_MODS}
    total_report = total_clinical = total_misc = 0
    for wd in DAY_ORDER:
        d = daily[wd]
        for m in ALL_MODS:
            totals[m] += d[m]
        total_report += d['report_min']
        total_clinical += d['clinical_min']
        total_misc += d['misc_min']
    return {
        'mods': totals,
        'report_min': total_report,
        'clinical_min': total_clinical,
        'misc_min': total_misc,
        'grand_total': sum(totals[m] for m in TRACKED_MODS) + totals.get('MR', 0),
    }


def compute_efficiency(daily: dict) -> dict:
    """Compute efficiency by sub-category across all days."""
    subs = defaultdict(lambda: {'c': 0, 'm': 0})
    for wd in DAY_ORDER:
        d = daily[wd]
        for sub, data in d['xr_sub'].items():
            subs[f'X光({sub})']['c'] += data['c']
            subs[f'X光({sub})']['m'] += data['m']
        for sub, data in d['ct_sub'].items():
            subs[f'CT({sub})']['c'] += data['c']
            subs[f'CT({sub})']['m'] += data['m']
        for sub, data in d['us_sub'].items():
            subs[f'US({sub})']['c'] += data['c']
            subs[f'US({sub})']['m'] += data['m']

    # Add non-sub modalities
    for mod in ['Mammo', 'MR', 'IVP']:
        total_c = sum(daily[wd][mod] for wd in DAY_ORDER)
        total_m = sum(e['mins'] for wd in DAY_ORDER for e in daily[wd]['entries'] if e['mod'] == mod)
        if total_c > 0:
            subs[mod] = {'c': total_c, 'm': total_m}

    result = {}
    for key, data in sorted(subs.items()):
        if data['m'] > 0 and data['c'] > 0:
            actual = data['c'] / (data['m'] / 60)
            baseline = BASELINES.get(key)
            diff_pct = ((actual - baseline) / baseline * 100) if baseline else None
            result[key] = {
                'count': data['c'], 'mins': data['m'],
                'actual_rate': round(actual, 1),
                'baseline': baseline,
                'diff_pct': round(diff_pct, 0) if diff_pct is not None else None
            }
    return result


def compute_tracking(week_input: dict, totals: dict) -> dict:
    """Compute remaining tracking with start/end data."""
    tracking = {}
    for mod in TRACKED_MODS:
        s = week_input['start'].get(mod)
        e = week_input['end'].get(mod)
        completed = totals['mods'].get(mod, 0)
        if s is not None and e is not None:
            added = e - s + completed
            pool = s + added
            digest_rate = completed / pool * 100 if pool > 0 else 0
            tracking[mod] = {
                'start': s, 'end': e, 'completed': completed,
                'added': added, 'net': e - s,
                'digest_rate': round(digest_rate, 1)
            }
        else:
            tracking[mod] = {
                'start': s, 'end': e, 'completed': completed,
                'added': None, 'net': None, 'digest_rate': None
            }
    return tracking


def main():
    parser = argparse.ArgumentParser(description='Generate radiology weekly report')
    parser.add_argument('xlsx', help='Path to tracker.xlsx')
    parser.add_argument('week_input', help='Path to week_input.md')
    parser.add_argument('-o', '--output', default='output/weekly_report.html')
    parser.add_argument('--history', default='data/history.json', help='Path to history.json')
    args = parser.parse_args()

    # Parse data
    entries = parse_xlsx(args.xlsx)
    week_info = parse_week_input(args.week_input)
    daily = group_by_day(entries)
    totals = compute_totals(daily)
    efficiency = compute_efficiency(daily)
    tracking = compute_tracking(week_info, totals)

    # Print summary (for Claude Code to read and generate HTML)
    print("=" * 70)
    print("WEEKLY REPORT DATA")
    print("=" * 70)

    print("\n── Tracking ──")
    for mod, t in tracking.items():
        if t['net'] is not None:
            print(f"  {mod}: {t['start']} → {t['end']} (net {t['net']:+d}, "
                  f"completed {t['completed']:.0f}, added ≥{t['added']:.0f}, "
                  f"digest {t['digest_rate']}%)")

    print(f"\n── Totals ──")
    for mod in ALL_MODS:
        if totals['mods'][mod] > 0:
            print(f"  {mod}: {totals['mods'][mod]:.0f}")
    print(f"  Grand total: {totals['grand_total']:.0f}")
    print(f"  Report time: {totals['report_min']:.0f}m ({totals['report_min']/60:.1f}hr)")
    print(f"  Clinical: {totals['clinical_min']:.0f}m, Misc: {totals['misc_min']:.0f}m")

    print(f"\n── Daily ──")
    for wd in DAY_ORDER:
        d = daily[wd]
        day_total = sum(d[m] for m in ALL_MODS)
        if day_total > 0 or d['entries']:
            note = f" [{', '.join(d['notes'])}]" if d['notes'] else ""
            clin = f" +clin {d['clinical_min']:.0f}m" if d['clinical_min'] > 0 else ""
            print(f"  {wd}: {day_total:.0f}份 / {d['report_min']:.0f}m ({d['report_min']/60:.1f}hr){clin}{note}")

    print(f"\n── Efficiency ──")
    for key, e in efficiency.items():
        diff_str = f" ({e['diff_pct']:+.0f}%)" if e['diff_pct'] is not None else ""
        print(f"  {key}: {e['count']:.0f}份/{e['mins']:.0f}m = {e['actual_rate']}/hr"
              f" [base: {e['baseline']}]{diff_str}")

    print(f"\n── Output ──")
    print(f"  Report data ready. Use Claude to generate HTML or pipe to template.")

    # Save as JSON for potential further processing
    report_data = {
        'tracking': tracking,
        'totals': {k: v if not isinstance(v, float) else round(v, 1) for k, v in totals.items()},
        'efficiency': efficiency,
        'daily': {wd: {
            'total': sum(daily[wd][m] for m in ALL_MODS),
            'report_min': daily[wd]['report_min'],
            'clinical_min': daily[wd]['clinical_min'],
            **{m: daily[wd][m] for m in ALL_MODS if daily[wd][m] > 0}
        } for wd in DAY_ORDER},
    }

    json_path = args.output.replace('.html', '.json')
    Path(json_path).parent.mkdir(parents=True, exist_ok=True)
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(report_data, f, ensure_ascii=False, indent=2, default=str)
    print(f"  JSON saved to: {json_path}")


if __name__ == '__main__':
    main()
